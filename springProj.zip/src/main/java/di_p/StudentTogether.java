package di_p;

public class StudentTogether {
	String [] name;
	
	
	
}
