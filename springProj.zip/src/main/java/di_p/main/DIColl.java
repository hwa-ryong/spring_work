package di_p.main;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DIColl {
	
	String nick;
	int age;
	
	int [] arr, arr1;
	
	List arr2;
	
	Set ss1;
	
	Map mm1;
	
	
	public int[] getArr1() {
		return arr1;
	}
	
	public void setArr1(int... arr1) {
		this.arr1 = arr1;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int[] getArr() {
		return arr;
	}

	public void setArr(int[] arr) {
		this.arr = arr;
	}

	public List getArr2() {
		return arr2;
	}

	public void setArr2(List arr2) {
		this.arr2 = arr2;
	}

	public Set getSs1() {
		return ss1;
	}

	public void setSs1(Set ss1) {
		this.ss1 = ss1;
	}

	public Map getMm1() {
		return mm1;
	}

	public void setMm1(Map mm1) {
		this.mm1 = mm1;
	}

	

	
	
}
