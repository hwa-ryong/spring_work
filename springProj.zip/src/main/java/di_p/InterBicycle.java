package di_p;

public interface InterBicycle {
	
}
