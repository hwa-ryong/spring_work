package aaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjApplication.class, args);
	}

}
